package com.nl.clubbook.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import com.nl.clubbook.R;

/**
 * Created by odats on 18/06/2014.
 */
public class NoLocationActivity extends BaseActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.no_location);
    }
}