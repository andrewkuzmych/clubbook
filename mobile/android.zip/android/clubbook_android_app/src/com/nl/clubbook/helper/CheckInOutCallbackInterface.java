package com.nl.clubbook.helper;

/**
 * Created by Andrew on 6/3/2014.
 */
public interface CheckInOutCallbackInterface {
    void onCheckInOutFinished(boolean result);
}
