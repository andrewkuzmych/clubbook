package com.nl.clubbook.helper;

import android.content.Intent;
import android.graphics.drawable.Drawable;

/**
 * Created by Andrew on 5/21/2014.
 */
public class CropOption {
    public CharSequence title;
    public Drawable icon;
    public Intent appIntent;
}
