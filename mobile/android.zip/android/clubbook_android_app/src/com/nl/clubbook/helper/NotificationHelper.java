package com.nl.clubbook.helper;

import com.pubnub.api.Pubnub;

/**
 * Created by Andrew on 6/11/2014.
 */
public class NotificationHelper {
    public static Pubnub pubnub = new Pubnub("pub-c-b0a0ffb6-6a0f-4907-8d4f-642e500c707a", "sub-c-f56b81f4-ed0a-11e3-8a10-02ee2ddab7fe", "", false);


}
